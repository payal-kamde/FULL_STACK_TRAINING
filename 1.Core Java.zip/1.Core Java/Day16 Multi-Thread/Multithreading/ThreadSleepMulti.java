//sleep() method using multiple threading
public class ThreadSleepMulti extends Thread
{
 public void run()
 {
  for(int i=1;i<=3;i++)
  {
   try
   {
   
    Thread.sleep(10);
	Sytem.out.println(Thread.currentThread().getName);
	
   }
  
  catch(Exception e)
  {
   e.printStackTrace();
  }
  
  System.out.println(i);
  }
  }
 public static void main(String args[])
 {
  ThreadSleepDemo1 ts = new ThreadSleepDemo1();
  ts.start();
 }
}