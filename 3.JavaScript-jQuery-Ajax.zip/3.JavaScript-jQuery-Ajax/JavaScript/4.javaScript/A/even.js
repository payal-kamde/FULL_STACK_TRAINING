for(let i=2;i<=10;i++)
{
	if(i%2==0)
	{
		console.log("Table of "+i+" :");
		for(let n=1;n<=10;n++)
		console.log(i+" * "+n+" = "+i*n);
	}
}