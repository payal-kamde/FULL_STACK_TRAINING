// Hello outer method ,Inner show method 10
class Outer
{
	static int x=10;
   void show1()
   {
      System.out.println("Hello outer method");
   }
    static class Inner
   {
	    void show()
   {
	   System.out.println("Inner show method " + x);
   }
   }
 }
 public class OuterDemo5
 {
	 public static void main(String args[])
	 {
		 Outer o=new Outer();
		 o.show1(); 
		 Outer.Inner oi=new Outer.Inner();
		 oi.show();
	 }
 }
 
