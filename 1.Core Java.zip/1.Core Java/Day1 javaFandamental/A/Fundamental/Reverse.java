class Reverse  
{  
  public static void main(String[] args)   
 {  
    int reverse = 0; 
   int n = Integer.parseInt(args[0]); 
   while(n != 0)   
  {  
   int remainder = n % 10;  
   reverse = reverse * 10 + remainder;  
   n = n/10;  
  }  
  System.out.println("The reverse number is: " + reverse);  
 }  
}  