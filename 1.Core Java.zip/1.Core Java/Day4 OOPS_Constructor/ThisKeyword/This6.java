class PQR
{
PQR getPQR()
{
return this;

}
void msg()
{
System.out.println("Hello Every One");
}

}
class This6
{
public static void main(String args[])
{
new PQR().getPQR().msg();
}
}