import newPackage.Student;
import newPackage.Teacher;
import java.util.Scanner;

class School
{
 public static void main(String args[])
 {
	 Scanner input = new Scanner(System.in);
	 System.out.println("Enter your Details");
	 
	 
	 System.out.println("Please Enter Student Details");
	 Student s = new Student();
     
	   System.out.print("Enter Student Name: ");
	   String name= input.nextLine();
	   s.setName(name);
	   
	   System.out.print("Enter Student Roll Number: ");
	   int roll= input.nextInt();
	   s.setRolln(roll);
	   
	   System.out.print("Student Gender: ");
	   char gen= input.next(".").charAt(0);
	   s.setGender(gen);
	   
	   System.out.print("Student Fees: ");
	   int fees= input.nextInt();
	   s.setFees(fees);
	   
	   System.out.println("");
	   System.out.println("Please Enter Teacher Details");
	   Teacher t = new Teacher();
	   
	   System.out.println("Enter Teacher Name: ");
	   String tname= input.nextLine();
	   t.setTName(tname);
	   
	   System.out.print("Enter Teacher ID: ");
	   int id= input.nextInt();
	   t.setTId(id);
	   
	   System.out.print("Enter Teacher Gender: ");
	   char gen1= input.next(".").charAt(0);
	   t.setTGender(gen1);
	   
	   System.out.print("Enter Teacher Salary: ");
	   int salary= input.nextInt();
	   t.setTSalary(salary);
	   
	 
	 System.out.println("Please enter number to show details");
   System.out.println("1. Student");
   System.out.println("2. Teacher");
	 
	  
	   System.out.print("Enter your choice: ");
	   Scanner input1 = new Scanner(System.in);
       String choice1 = input1.nextLine();
       System.out.println("My choice is: " + choice1);
       input.close();
   
   if(choice1.equals("1"))
   {
		
		
		System.out.println("Student Name:" +s.getName());
		System.out.println("Student Roll Number:" +s.getRolln());
		System.out.println("Student Gender:" +s.getGender());
		System.out.println("Student Fees:" +s.getFees());
	   
   }
   else if(choice1.equals("2"))
   {
		System.out.println("Teacher Name:" +t.getTName());
		System.out.println("Teacher ID:" +t.getTId());
		System.out.println("Teacher Gender:" +t.getTGender());
		System.out.println("Teacher Salary:" +t.getTSalary());
   
   }
   else
   {
		System.out.println("Invalid Entry!");
   }
  
  
   
   
   
 }
}