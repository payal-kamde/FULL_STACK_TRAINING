class SortArray
{
 public static void main(String args[])
 {
  int array[]={7,15,22,48,55};
  int num=0;
  for(int i=0;i<array.length;i++)
  {
   if(array[i]>num)
   {
	num= array[i];
	
   }
    System.out.println(num);
  }
 }
}