import java.util.Vector;
import java.util.Iterator;

class VectorExample1
{
  public static void main(String[] args)
  {
   Vector<String> vec = new Vector<>();
   vec.add("10");
   vec.add("50");
   vec.add("90");
	
  Iterator<String> itr = vec.iterator();
  while(itr.hasNext())
  {
			
   System.out.print(itr.next() + " ");
  }
		
   vec.remove("10");
		
   System.out.println(vec);
 }
}