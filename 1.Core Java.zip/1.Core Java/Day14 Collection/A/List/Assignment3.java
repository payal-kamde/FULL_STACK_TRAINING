import java.util.Vector;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;

class Assignment3{
	public static void main(String[] args){
Vector<String> vec = new Vector<>();
		vec.add("Jan");
		vec.add("Feb");
		vec.add("Mar");
		vec.add("April");
		vec.add("May");
		vec.add("June");
		vec.add("July");
		vec.add("Aug");
		vec.add("Sep");
		vec.add("Oct");
		vec.add("Nov");
		vec.add("Dec");
		Iterator<String> itr = vec.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		vec.remove("Jan");
		
		System.out.println(vec);
		 Collection<String> c = new ArrayList<String>();
        c.add("Jan");
        c.add("Feb");
        c.add("Mar");
        c.add("Apr");
        c.add("May");
  
       System.out.println("The Vector is: " + vec);
  
        vec.addAll(c);
		System.out.println("The new vector is: " + vec);
	}
}