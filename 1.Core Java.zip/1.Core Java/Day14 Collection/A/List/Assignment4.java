//Assignment 3
import java.util.Iterator;
import java.util.Vector;

class AssociateTrainee {
	private int id;
	private String name;
	private Double salary;
	
	public AssociateTrainee(int id, String name, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}	
	
	public int getId() {
		return id;
	}

	//@Override
	public String toString() {
		return "AssociateTrainee [id=" + id + ", name=" + name +  ", salary=" + salary + "]";
	}
}

public class Assignment4 {

	public static void main(String[] args) {
		Vector<AssociateTrainee> list = new Vector<>();
		
		list.add(new AssociateTrainee(100, "Nisha", 20000.0));
		list.add(new AssociateTrainee(101, "Nitika", 30000.0));
		list.add(new AssociateTrainee(102, "Karthik", 25000.0));
		list.add(new AssociateTrainee(103, "Amit", 40000.0));
		
		Iterator<AssociateTrainee> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}

}
