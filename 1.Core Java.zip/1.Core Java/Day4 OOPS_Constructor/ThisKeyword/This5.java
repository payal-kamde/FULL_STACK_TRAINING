class t1
{
 t1(This5 td)
 {
  System.out.println("t1 class constructor");
 }
}
class This5
{
 void y1()
 {
  t1 t = new t1(this);
 }
 public static void main(String args[])
 {
  This5 t = new This5();
  t.y1();
 }
}