class BookTicket
{
    int totalseats=12;
	synchronized void bookseat(int seats)
	{
	   synchronized(this)
	   {
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats"+totalseats);
		}
		else
		{
			System.out.println("Seats are not available"+totalseats);
		}
	  }
    }
}
public class TicketWithSynch1 extends Thread
{	
    static BookTicket b;
	int seats;
	public void run()
	{
		b.bookseat(seats);
	}
	public static void main(String[] args)
	{
		b=new BookTicket();
		TicketWithSynch1 p1=new TicketWithSynch1();
		p1.seats=8;
		p1.start();
		TicketWithSynch1 p2=new TicketWithSynch1();
		p2.seats=10;
		p2.start();
	}
}
