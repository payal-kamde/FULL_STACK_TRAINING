import React, {Component} from 'react';

class Content2 extends React.Component

{

render()

{

    return(

        <div>

            <h2>LOGIN PAGE</h2>
            <fieldset>
            <form>
                
            <label> Username </label>
            <input type="text" name="username" size="15"/> 
            <br></br>
            <br></br>
            <label> Password: </label>
            <input type="text" name="password" size="15"/>  
            <br></br>
            <br></br>
            
            <input type="button" value="Submit"/>
            </form>
            </fieldset>
            
            

        </div>

    );

}



}

export default Content2;