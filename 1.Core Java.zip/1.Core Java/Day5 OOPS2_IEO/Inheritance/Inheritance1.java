class AnimalE
{
  public void eat()
  {
   System.out.println("eat method");
  }
  public void sleep()
  {
   System.out.println("sleep method");
  }
}
class Bird extends AnimalE
{
  public void eat()
 {
  super.eat();
  System.out.println("override eat");
 }
 public void sleep()
 {
 super.sleep();
 System.out.println("override sleep");
 }
 public void fly()
 {
 System.out.println("In fly method");
 }
}
class Inheritance1
{
 public static void main(String[] args)
 {
  AnimalE a=new AnimalE();
  Bird b=new Bird();
  a.eat();
  a.sleep();
  b.eat();
  b.sleep();
  b.fly();

 }
}