package com.sms.SchoolManagementSystem.Main;
import com.sms.SchoolManagementSystem.bin.StudentBin;
import com.sms.SchoolManagementSystem.bin.TeacherBin;
import com.sms.SchoolManagementSystem.dao.StudentDao;
import com.sms.SchoolManagementSystem.dao.TeacherDao;
import com.sms.SchoolManagementSystem.exception.InputException;
import com.sms.SchoolManagementSystem.exception.DataNotFound;
import com.sms.SchoolManagementSystem.exception.ConnectionUtilityException;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

public class School {
	
	public static void main(String args[]) throws  Exception,InputException,DataNotFound
	 {
		 //Using BufferedReader user input
		 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		 
		 System.out.println("Enter your Details");
		 
		 System.out.println("Please enter number to show details");
	     System.out.println("1. Student");
	     System.out.println("2. Teacher");
		 
	     System.out.print("Enter your choice: ");
	     BufferedReader br2  =new BufferedReader(new InputStreamReader(System.in));
		 String choice2=br2.readLine();
		 System.out.println("My choice is: " + choice2);
		 
		 if(choice2.equals("1")) {
			 System.out.println("Please enter number to show details");
		     System.out.println("1. Insert Student data");
		     System.out.println("2. Update Student data");
		     System.out.println("3. Delete Student data");
		     System.out.println("4. show single Student data");
		     System.out.println("5. show all Student data");
		     
			 
		     System.out.print("Enter your choice: ");
		     BufferedReader choiceForStudent  =new BufferedReader(new InputStreamReader(System.in));
			 String choose=choiceForStudent.readLine();
			 if(choose.equals("1")) {
				 System.out.println("Please Enter Student Details");
				 StudentBin s = new StudentBin();
				 
				  System.out.print("Enter Student Roll Number: ");
				   int roll= Integer.parseInt(br.readLine());
				   s.setRolln(roll);
			     
				   System.out.print("Enter Student Name: ");
			       String name = br.readLine();
				   s.setName(name);
				  
				   
				   System.out.print("Student Gender: ");
				   String gen= br.readLine();
				   s.setGender(gen);
				   
				   System.out.print("Student Fees: ");
				   int fees= Integer.parseInt(br.readLine());
				   s.setFees(fees);
				   
				   StudentDao studentDao = new StudentDao(); 
				   studentDao.insertStudent(s);
			 }
			 else if (choose.equals("2")) {
				 
				 System.out.println("Please Enter Student Details");
				 StudentBin s = new StudentBin();
				 
				 System.out.print("Please enter student id which you want to update: ");
				 int id= Integer.parseInt(br.readLine());
				 
				 
				  System.out.print("Enter Student Roll Number: ");
				   int roll= Integer.parseInt(br.readLine());
				   s.setRolln(roll);
			     
				   System.out.print("Enter Student Name: ");
			       String name = br.readLine();
				   s.setName(name);
				  
				   
				   System.out.print("Student Gender: ");
				   String gen= br.readLine();
				   s.setGender(gen);
				   
				   System.out.print("Student Fees: ");
				   int fees= Integer.parseInt(br.readLine());
				   s.setFees(fees);
				 
				   StudentDao studentDao = new StudentDao(); 
				   studentDao.updateStudent(s, id);
				 
			 }
			 else if(choose.equals("3")) {
				 System.out.print("Please enter student id which you want to delete: ");
				 int id= Integer.parseInt(br.readLine());
				 StudentDao studentDao = new StudentDao(); 
				 studentDao.deleteStudent(id);
			 }
			 else if(choose.equals("4")) {
				 System.out.print("Please enter student id which you want to show: ");
				 int id= Integer.parseInt(br.readLine());
				 StudentDao studentDao = new StudentDao(); 
				 StudentBin stu = studentDao.showStudent(id);
				 System.out.println(stu.toString());
			 }
			 else if(choose.equals("5")) {
				 StudentDao studentDao = new StudentDao(); 
				 List <StudentBin> stuList = studentDao.showAllStudent();
				 System.out.println(stuList.toString());
				 
			 }
			 
			 
		 }
		 else {
			 
			 System.out.println("Please enter number to show details");
		     System.out.println("1. Insert Teacher data");
		     System.out.println("2. Update Teacher data");
		     System.out.println("3. Delete Teacher data");
		     System.out.println("4. show single Teacher data");
		     System.out.println("5. show all Teacher data");
			 
		     

		     System.out.print("Enter your choice: ");
		     BufferedReader choiceForStudent  =new BufferedReader(new InputStreamReader(System.in));
			 String choose=choiceForStudent.readLine();
			 if(choose.equals("1")) {
				 System.out.println("");
				   System.out.println("Please Enter Teacher Details");
				   TeacherBin t = new TeacherBin();
				   
				   System.out.print("Enter Teacher ID: ");
				   int id= Integer.parseInt(br.readLine());
				   t.setTId(id);
				   
				   System.out.print("Enter Teacher Name: ");
				   String tname= br.readLine();
				   t.setTName(tname);
				  
				   
				   System.out.print("Enter Teacher Gender: ");
				   String gen1=  br.readLine();
				   t.setTGender(gen1);
				   
				   System.out.print("Enter Teacher Salary: ");
				   int salary= Integer.parseInt(br.readLine());
				   t.setTSalary(salary);
				   
				   
				   TeacherDao teacherDao = new TeacherDao();
				   teacherDao.insertTeacher(t);
			 }
			 else if (choose.equals("2")) {
				 
				 System.out.println("Please Enter Teacher Details");
				 TeacherBin t = new TeacherBin();
				 
				 System.out.print("Please enter Teacher id which you want to update: ");
				 int techId= Integer.parseInt(br.readLine());
				 
				 
				 System.out.print("Enter Teacher ID: ");
				   int id= Integer.parseInt(br.readLine());
				   t.setTId(id);
				   
				   System.out.print("Enter Teacher Name: ");
				   String tname= br.readLine();
				   t.setTName(tname);
				  
				   
				   System.out.print("Enter Teacher Gender: ");
				   String gen1=  br.readLine();
				   t.setTGender(gen1);
				   
				   System.out.print("Enter Teacher Salary: ");
				   int salary= Integer.parseInt(br.readLine());
				   t.setTSalary(salary);
				   
				   
				   TeacherDao teacherDao = new TeacherDao();
				   teacherDao.updateTeacher(t, techId);
				 
			 }
			 else if(choose.equals("3")) {
				 System.out.print("Please enter Teacher id which you want to delete: ");
				 int id= Integer.parseInt(br.readLine());
				 TeacherDao TeacherDao = new TeacherDao(); 
				 TeacherDao.deleteTeacher(id);
			 }
			 else if(choose.equals("4")) {
				 System.out.print("Please enter Teacher id which you want to show: ");
				 int id= Integer.parseInt(br.readLine());
				 TeacherDao TeacherDao = new TeacherDao(); 
				 TeacherBin stu = TeacherDao.showTeacher(id);
				 System.out.println(stu.toString());
			 }
			 else if(choose.equals("5")) {
				 TeacherDao TeacherDao = new TeacherDao(); 
				 List <TeacherBin> stuList = TeacherDao.showAllTeacher();
				 System.out.println(stuList.toString());
				 
			 }
		     
		 }
		 
		 
		 
		   
	   
	 }

}
