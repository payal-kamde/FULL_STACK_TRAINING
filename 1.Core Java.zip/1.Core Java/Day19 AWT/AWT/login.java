import java.awt.*;

class login
{
 public static void main(String args[])
 {
  Frame f = new Frame();
  f.setVisible(true);
  f.setSize(500,900);
 }
}