//Singal task using MultipleThread
public class MultipalThread extends Thread
{
 public void run()
 {
 
  System.out.println("Hello Everyone");
 }
 public static void main(String args[])
 {
  MultipalThread mt = new MultipalThread();
   mt.start();
    MultipalThread mt1 = new MultipalThread();
   mt1.start();
 }
}