//    multilevel inheritance

class A
{
 void displayA()
 {
  System.out.println("A class");
  
 }
}
class B extends A
{
 void displayB()
 {
  System.out.println("B class");
 }
}
class C extends B
{
 void displayC()
 {
  System.out.println("C class");
 }
 public static void main(String args[])
 {
  A ob1 = new A();
  ob1.displayA();
  
   B ob2 = new B();
  ob2.displayA();
  ob2.displayB();
  
   C ob3 = new C();
  ob3.displayA();
  ob3.displayB();
  ob3.displayC();
 }
}