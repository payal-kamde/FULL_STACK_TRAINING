package com.sms.SchoolManagementSystem.exception;
public class InputException extends Exception
{
	
	public  InputException()
		{
			super();
		}
		public  InputException(String message)
		{
			super(message);
		}
	}

