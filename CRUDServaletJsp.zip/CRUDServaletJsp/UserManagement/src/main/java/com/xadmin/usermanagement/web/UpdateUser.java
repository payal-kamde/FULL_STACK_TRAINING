package com.xadmin.usermanagement.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateUser
 */
@WebServlet("/UpdateUser")
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String email = request.getParameter("email");
		String country = request.getParameter("country");
		
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/userdb";
		String user = "root";
		String pass ="root";
		Connection con = DriverManager.getConnection(url,user,pass);
		
		String quary1="update users set name=?,email=?,country=? where id=?";
		PreparedStatement prst = con.prepareStatement(quary1);
		prst.setString(1,name);
		prst.setString(2,email);
		prst.setString(3,country);
		prst.setInt(4,id);
		prst.executeUpdate();
		
		out.print("<h1>" + "user update sucessfully" +"</h1>");
		request.getRequestDispatcher("showtable.jsp").include(request, response);
		
		
		con.close();
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
