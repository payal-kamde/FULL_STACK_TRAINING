class StringFun
{
 public static void main(String args[])
 {
 String s = "Hello Payal";
 String s1 = "";
 System.out.println(s.isEmpty());
 System.out.println(s1.isEmpty());
 }
}