package com.yash.springjdbcfirst;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;



import com.yash.springjdbcfirst.dao.EmployeeDao;
import com.yash.springjdbcfirst.entities.Employee;
import com.yash.springjdbcfirst.dao.EmployeeDao;
import com.yash.springjdbcfirst.entities.Employee;



/**
* Hello world!
*
*/
public class App {
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbcfirst/applicationcontext.xml");
		EmployeeDao empdao = context.getBean("EmployeeDao", EmployeeDao.class);
		
		
		
		Employee e = new Employee();
		
		e.setEmpname("Madhav");
		e.setEmailid("md@gmail.com");
		e.setDob("15/02/2000");
		e.setContactno(7669255);
		e.setSalary(350000);
		
		//int r = empdao.insert(e);//insert
		
		//System.out.println(r + "Employee added Successfully ");
		
		//int r = empdao.updatedetails(e);
		
		//System.out.println(r + "Employee updated successfully");
		
		int r=empdao.deletedetails("abc");//delete the details
		System.out.println(r + "Employee deleted Successfully ");
	}
}

