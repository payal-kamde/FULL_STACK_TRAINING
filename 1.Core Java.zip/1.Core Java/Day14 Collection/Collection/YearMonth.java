import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
class YearMonth
{
  public static void main(String args[])
  {
   ArrayList<String> a = new ArrayList<String>();
   a.add("january");
   a.add("February");

a.add("March");
a.add("April");
a.add("May");
a.add("June");
a.add("July");
a.add("August");
a.add("September");
a.add("October");
a.add("November");
a.add("December");
System.out.println(a);

Iterator i = a.iterator();
while(i.hasNext())
{
 System.out.println(i.next());
}

for(String j:a)
{
 System.out.println("FOR EACH: " +j);
}

System.out.println("Get element index 1" +a.get(1));
a.set(2, "payal");
for(String j:a)
{
 System.out.println("FOR EACH: " +j);
}

Collections.sort(a);
for(String j:a)
{
 System.out.println("FOR EACH:" +j);
}
}

}

