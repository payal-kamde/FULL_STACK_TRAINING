package com.yash.springjdbcfirst.entities;

public class Employee 
{
	private String empname;
	private String emailid;
	private String dob;
	private int contactno;
	private int salary;
	@Override
	public String toString() 
	{
		return "Employee [empname=" + empname + ", emailid=" + emailid + ", dob=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}
	
	public Employee() {
		super();
	}

	public Employee(String empname, String emailid, String dob, int contactno, int salary) 
	{
		super();
		this.empname = empname;
		this.emailid = emailid;
		this.dob = dob;
		this.contactno = contactno;
		this.salary = salary;
	}
	public String getEmpname() 
	{
		return empname;
	}
	public void setEmpname(String empname) 
	{
		this.empname = empname;
	}
	public String getEmailid() 
	{
		return emailid;
	}
	public void setEmailid(String emailid)
	{
		this.emailid = emailid;
	}
	public String getDob() 
	{
		return dob;
	}
	public void setDob(String dob)
	{
		this.dob = dob;
	}
	public int getContactno()
	{
		return contactno;
	}
	public void setContactno(int contactno) 
	{
		this.contactno = contactno;
	}
	public int getSalary()
	{
		return salary;
	}
	public void setSalary(int salary) 
	{
		this.salary = salary;
	}
	
	
	
	
	

}
