package Springsimpleapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Springfirstapp.Employee;

public class App {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Spring First Application");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e = (Employee) context.getBean("employee");
		System.out.print(e);
		Employee e1 = (Employee) context.getBean("employee1");
		System.out.print(e1);

		
		
	}

}
