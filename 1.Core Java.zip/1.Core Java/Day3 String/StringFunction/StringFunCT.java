class StringFunCT
{
 public static void main(String args[])
 {
  String s = "Payal";
  String s1 = "Payal"; 
  String s2 = "Medy";
  String s3 = "Yash";
  String s4 = "Sakshi";
  

 System.out.println(s.compareTo(s1));
 System.out.println(s.compareTo(s2));
 System.out.println(s.compareTo(s3));
 System.out.println(s.compareTo(s4));
  
 }
}
