class Bike
{
	String bname;
	int bprice;
	
 Bike()
 {
  System.out.println("This is Bike ");
 
 }
 
 Bike(String bname , int bprice )
 {
	 this.bname =bname;
	 this.bprice= bprice;
	 System.out.println("bike name:"+this.bname);
	 System.out.println("bike price:"+this.bprice);
 }
 
 public static void main(String args[])
 {
  Bike b = new Bike();
   System.out.println("new bike");
   
   Bike b1 = new Bike("X-blead",135000);

 }
}


	

