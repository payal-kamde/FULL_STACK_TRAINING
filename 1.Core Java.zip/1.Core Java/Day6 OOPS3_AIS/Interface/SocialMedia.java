interface Facebook
{
 void show();
}
interface Instagram
{
 void display();
}
class SocialMedia implements Facebook, Instagram
{
  public void show()
  {
   System.out.println("In show facebook");
  }
  
  public void display()
  {
   System.out.println("In show Instagram");
  }
  public static void main(String args[])
  {
   SocialMedia sm = new SocialMedia();
   sm.show();
   sm.display();
  }
}