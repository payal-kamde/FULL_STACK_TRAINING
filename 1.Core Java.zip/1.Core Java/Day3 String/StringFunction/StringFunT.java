class StringFunT
{
 public static void main(String args[])
 {
 String s = " Welcom to the Yash Technologies  ";

 System.out.println(s.trim());

 
 s = " I am very Happy";
  System.out.println(s.trim());
 }
}