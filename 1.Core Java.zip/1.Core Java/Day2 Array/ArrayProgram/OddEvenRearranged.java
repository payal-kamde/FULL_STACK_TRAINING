class OddEvenRearranged{
	public static void main(String[] args){
		int[] a = {1,2,3,5};
		int[] b = {8,6,9,4};
		
		int[] c = new int[a.length + b.length];
		
		int odd = c.length - 1;
		int even = 0;
		
		for(int i = 0; i < a.length; i++){
			if(a[i] % 2 == 0){
				c[even] = a[i];
				even++;
			} else{
				c[odd] = a[i];
				odd--;
			}
		}
		
		for(int i = 0; i < b.length; i++){
			if(b[i] % 2 == 0){
				c[even] = b[i];
				even++;
			} else{
				c[odd] = b[i];
				odd--;
			}
		}
		
		for(int i = 0; i < c.length; i++){
			System.out.print(c[i] + " ");
		}
		
		
	}
}