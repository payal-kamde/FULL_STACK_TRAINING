import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
class YearMonth1
{
  public static void main(String args[])
  {
   ArrayList<String> a = new ArrayList<String>();
   a.add("january");
   a.add("February");

a.add("March");
a.add("April");
a.add("May");
a.add("June");
a.add("July");
a.add("August");
a.add("September");
a.add("October");
a.add("November");
a.add("December");
System.out.println(a);

ListIterator li = a.listIterator();
li.next();
li.next();
li.next();
while(li.hasPrevious())
{
 System.out.println(li.previous());
}

li.set("Sunday");
System.out.println(a);



}
}