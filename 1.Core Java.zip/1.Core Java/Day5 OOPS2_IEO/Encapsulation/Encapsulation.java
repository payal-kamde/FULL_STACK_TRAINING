class Author
{
 private String name,email;
 private char gender;
 
 Author(String name, String email, char gender)
 {
   this.name = name;
   this.email = email;
   this.gender = gender;
 }
 public String getName(){
	return this.name;
 }
 
 public String getEmail(){
	return this.email;
 }
 
 public char getGender(){
	return this.gender;
 }
}



class Book
{
 private String name;
 private double price;
 private Author a;
 private int qtyInStock;
 
 
 public void setName(String name)
 {
  this.name = name;
 }
 
 public void setPrice(double price)
 {
  this.price = price;
 }
 
 public void setAuthor(Author a)
 {
  this.a = a;
 }
 
 public void setQtyInStock(int qtyInStock)
 {
  this.qtyInStock = qtyInStock;
 }
 
 public String getName()
 {
   return name;
 }
 
 public double getPrice()
 {
  return price;
 }
 
 public Author getAuthor()
 {
  return a;
 }
 public int getQtyInStock()
 {
  return qtyInStock;
 }
}


public class Encapsulation
{
 public static void main(String args[])
 {
 Author au = new Author("Mahesh","mahesh@gmail.com", 'M');
  Book b = new Book();
  b.setName("Payal");
  b.setPrice(456.34);
  b.setAuthor(au);
  b.setQtyInStock(6);
  System.out.println("Name "+b.getName());
  System.out.println("Price "+b.getPrice());
  System.out.println("Author Name "+b.getAuthor().getName() + ", Email " + b.getAuthor().getEmail() + ", Gender " + b.getAuthor().getGender());
  System.out.println("QtyInStock "+b.getQtyInStock());
 }
}