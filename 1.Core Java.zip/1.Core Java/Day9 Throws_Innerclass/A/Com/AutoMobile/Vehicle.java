package com.AutoMobile;

public abstract class Vehicle 
{
	public abstract void getModelName();
	public abstract void getRegistrationNumber();
	public abstract void getOwnerName();
}