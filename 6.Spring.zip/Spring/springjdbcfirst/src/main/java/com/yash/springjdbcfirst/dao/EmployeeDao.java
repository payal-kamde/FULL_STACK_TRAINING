package com.yash.springjdbcfirst.dao;
import com.yash.springjdbcfirst.entities.Employee;

public interface EmployeeDao
{
	public int insert(Employee emp);
	public int updatedetails(Employee emp);
	public int deletedetails(String emp);
	
}

