package com.yash.springjdbc;
import java.util.List;
import java.util.Scanner;





import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;





import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;





/**
* Hello world!
*
*/
public class App 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);
		Scanner scanner = new Scanner(System.in);
		
		
		
		
		
		System.out.print(" Enter user name => ");
		String userName = scanner.nextLine();
		
		
		
		
		
		System.out.print(" Enter password => ");
		String password = scanner.nextLine();
		
		
		
		
		
		if ("payal".equals(userName) && "password".equals(password))
		{
			System.out.println(" You are successfully logged into the system ");
		} else 
		{
			System.out.println(" OOPS... invalid password ");
		}
		
		
		
		
		
		System.out.println("Enter the operation which you want to perform");
		System.out.println("1 for insert");
		System.out.println("2 for read");
		System.out.println("3 for update");
		System.out.println("4 for delete");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		
		
		
		
		
		if (a == 1)
		{
		
		
		
			Student s = new Student();
			System.out.println("Enter the emp id");
			int id = sc.nextInt();
			s.setId(id);
			System.out.println("Enter the name");
			String name = sc.next();
			s.setName(name);
			int r = stdao.insert(s);// insert the details
			System.out.println("New Student added successfully");
		}
		
		
		
		
		
		else if (a == 2) 
		{
			List<Student> stu = stdao.getAllDetails();
			for (Student s : stu) {
			System.out.println(s);
		}
		} else if (a == 3) 
		{
			Student s = new Student();
			System.out.println("Enter the emp id that you want to update");
			int id = sc.nextInt();
			System.out.println("Enter the updated name in record");
			String name = sc.next();
			s.setName(name);
			int r = stdao.updatedetails(s);
			System.out.println(r + "Student details updated ");
		}
		
		
		
		
		
		else if (a == 4) {
		System.out.println("Enter the emp id that you want to delete");
		int id = sc.nextInt();
		int r = stdao.deletedetails(id);// delete the details
		// Student s = stdao.selectDetails(106);
		System.out.println("student with id " + id + " deleted successfully");
		
		
		
		
		
		}
	}
}