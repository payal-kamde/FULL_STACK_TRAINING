class Duplicate
{
 public static void main(String args[])
 {
  int a[] = {3,1,5,7,2,1,3};
 
  for(int i=1;i<a.length;i++)
  {
   for(int j=i+1;j<a.length;j++)
   {
    if((a[i]==a[j])&&(i!=j))
	{
	 
    System.out.println(a[j]+",");
	}
   }
 }
   
 }
}