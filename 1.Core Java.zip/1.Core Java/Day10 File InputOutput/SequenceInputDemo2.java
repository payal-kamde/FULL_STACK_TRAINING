import java.io.*;    
class SequenceInputDemo2
{    
  public static void main(String args[])throws Exception{    
   FileInputStream fin1=new FileInputStream("D:/JavaFullStackTrainning/Day10/abc.txt");    
   FileInputStream fin2=new FileInputStream("D:/JavaFullStackTrainning/Day10/xyz.txt");    
   FileOutputStream fout=new FileOutputStream("D:/JavaFullStackTrainning/Day10/combine.txt");      
   SequenceInputStream s1=new SequenceInputStream(fin1,fin2);    
   int i;    
   while((i=s1.read())!=-1)    
   {    
     fout.write(i);        
   }    
   s1.close();    
   fout.close();      
   fin1.close();      
   fin2.close();       
   System.out.println("Program is Successfully Run..");  
  }    
}    