package com.yash.resoures;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App {



public static void main(String[] args) {
// TODO Auto-generated method stub


ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/resoures/applicationcontext.xml");
Employee employee=context.getBean("employee", Employee.class);
System.out.println(employee.getEmployeeId()+ "\t"+employee.getEmployeeName());

System.out.println("----------------");
Pancard pancard = employee.getPancard();
if(pancard != null)
	System.out.println(pancard.getPanHolderName()+"\t"+pancard.getPanNo());
else
	System.out.println("Pancard info is not availabel....");
	((AbstractApplicationContext) context).close();
}



}