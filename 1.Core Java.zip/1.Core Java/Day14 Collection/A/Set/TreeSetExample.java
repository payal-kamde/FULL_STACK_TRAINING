import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample
{

	public static void main(String[] args)
	{
		TreeSet<String> set = new TreeSet<>();

		set.add("Nisha");
		set.add("Nitika");
		set.add("Karthik");
		set.add("Amit");
		
		Iterator<String> it = set.iterator();
		String query = "payal";
		boolean result = false;
		
		while (it.hasNext())

			{
			if (it.next().equals(query)) 
			{
				result = true;
				break;
			}
		}
		
		if (result)
			System.out.println(query + " exists");
		else 
			System.out.println(query + " doesn't exist");

	}

}