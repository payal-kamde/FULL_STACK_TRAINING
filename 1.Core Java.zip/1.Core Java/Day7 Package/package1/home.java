package package1;
public class home
{
 public void show()
 {
  System.out .println("My Home");
 }
}