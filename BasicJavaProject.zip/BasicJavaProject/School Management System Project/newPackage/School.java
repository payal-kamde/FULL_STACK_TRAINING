package newPackage;
public class School
{
 private String s_name;
 private int classes;
 private String playGround;
 

public School()
{
	this.s_name=s_name;
	this.classes=classes;
	this.playGround=playGround;
	
}

public void setSName(String s_name)
{
	this.s_name=s_name;
	
}
public void setClasses(int classes)
{
	this.classes=classes;
	
}
public void setPlayGround(String playGround)
{
	this.playGround=playGround;
	
}

public String getSName()
{
	return s_name;
}
public int getClasses()
{
	return classes;
}
public String getPlayGround()
{
	return playGround;
}
}