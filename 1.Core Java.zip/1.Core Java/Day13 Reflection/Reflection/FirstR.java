class Hello{}    
    
public class FirstR
{    
 public static void main(String args[]) throws Exception 
 {    
  Class c=Class.forName("hihi");    
  System.out.println(c.getName());    
 }    
}    