public class ThreadInterptDemo extends Thread
{
 public void run()
 {
  try
  {
   for(int i)
  }
 }
}