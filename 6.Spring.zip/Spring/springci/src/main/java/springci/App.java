package springci;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Spring ");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e = (Employee) context.getBean("empci");
		System.out.print(e);
		
	}
}