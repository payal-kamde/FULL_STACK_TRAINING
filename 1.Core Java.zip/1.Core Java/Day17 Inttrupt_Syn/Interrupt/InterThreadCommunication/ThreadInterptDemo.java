public class ThreadInterptDemo extends Thread
{
 public void run()
 {
  try
  {
   for(int i=1;i<=3;i++)
   {
	   System.out.println(i);
   }
   catch(Exception e)
   {
	   System.out.println(e);
	   //e.printStackTrace();
   }
  }
  public static void main(String args[])
  {
	  ThreadInterptDemo t1 = new ThreadInterptDemo();
	  ti.start();
	  ti.interrupt();
  }
 )
 }
}