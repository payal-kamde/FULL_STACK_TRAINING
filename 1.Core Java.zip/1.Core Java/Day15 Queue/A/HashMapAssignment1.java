import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class HashMapAssignment1
{
 public static void main(String[] args) 
 {
	Map<String, String> map = new HashMap<>();
	map.put("India", "Delhi");
    map.put("4", "India");
    map.put("6", "Japan");

// a) Check if a particular key exists or not
    Set<Entry<String, String>> set = map.entrySet();
	Iterator<Entry<String, String>> it = set.iterator();

	while (it.hasNext()) 
	{
		Map.Entry<String, String> m = it.next();

		if (m.getKey().equals("4")) 
		{
			System.out.println("Key 4 exists");
			break;
		}
	}

// b) Check if a particular value exists or not
		set = map.entrySet();
		it = set.iterator();

		while (it.hasNext()) 
		{
			Map.Entry<String, String> m = it.next();

			if (m.getValue().equals("Delhi")) 
			{
				System.out.println("Value Delhi exists");
				break;
			}
		}

// c) Use Iterator to loop through the map key set
		set = map.entrySet();
		it = set.iterator();

		while (it.hasNext()) 
		{
		Map.Entry<String, String> m = it.next();
        System.out.println(m);
      //System.out.println("Key: " + m.getKey() + ", Value: " + m.getValue());
        }
 }

}