class DemoConstructor()
{
 int i;
 String s;
 public DemoConstructor()
 {
  System.out.println("Default Constructor");
  
 }
 public static void main(String args[])
 {
  DemoConstructor d = new DemoConstructor();
  System.out.println(d.i);
  System.out.println(t.s);
 }
}