
import java.util.*; 
import java.lang.*;
import java.io.*;

public class UnCheakException {
	 public static void main(String[] args)
	    {
	        
	        int a[] = { 10, 20, 30, 40,50 };
			 try
			 {
	  
	           
	  
	            System.out.println(a[6]);
	         }
	  
	        catch (ArrayIndexOutOfBoundsException e) 
			{
	  
	            
	            System.out.println("Out of index  please check your code");
	        }
			/*D:\JavaFullStackTrainning\Day12\cheakeUncheakExc>java UnCheakException
	         Out of index  please check your code*/
			 
			String m = null;
	 
	        try {
	            
	           
	            if (m.equals("UnCheakException")) 
				{
	              
	                System.out.println("YES");
	            }
	        }
	  
	       
	        catch (NullPointerException e)
			{
	 
	            System.out.println( "Object reference cannot be null");
	        }
			
			//Out of index  please check your code
	        //Object reference cannot be null
	    
	  
	  
	     try
		 {
			 int p=100,q=0,r;
			 r=p/q;
			 System.out.println(r);
		 }  
		 catch(ArithmeticException e)
		 {
			 e.printStackTrace();
		 }
		 /*Out of index  please check your code
	       Object reference cannot be null
	        java.lang.ArithmeticException: / by zero
	        at UnCheakException.main(UnCheakException.java:54)*/
			
		 try {
	           
	            
	            String s = "PAYAL";
	            Object o = (Object)s;
	           
	            System.out.println(o);
	        }
	        catch (Exception e) 
			{
	            System.out.println(e);
	        }
				/*Out of index  please check your code
				Object reference cannot be null
				java.lang.ArithmeticException: / by zero
				at UnCheakException.main(UnCheakException.java:56)
				PAYAL*/
				
				String cont = "y";
	            run(cont);
			
		}
		static void run(String cont) 
		{
	        Scanner scan = new Scanner(System.in);
	        while( cont.equalsIgnoreCase("y")) 
			{
	           try 
			   {
	               System.out.println("Enter an integer: ");
	               int marks = scan.nextInt();
	               if (marks < 0 || marks > 100)
	               throw new IllegalArgumentException("value must be non-negative and below 100");
	               System.out.println( marks);
	            }
	            catch(IllegalArgumentException i)
				{
	               System.out.println("out of range encouneterd. Want to continue");
	               cont = scan.next();  
	               if(cont.equalsIgnoreCase("Y"))
	                   run(cont);
	               }
	          }
		}
	}

}
