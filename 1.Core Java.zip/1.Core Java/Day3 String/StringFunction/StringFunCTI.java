class StringFunCTI
{
 public static void main(String args[])
 {
  String s = "Payal Kamde";
  String s1 = "PAYAL KAMDE"; 
  String s2 = "Payal";
  String s3 = "PayAL KamDE";
  
  int a = s.compareToIgnoreCase(s1);
  int b = s.compareToIgnoreCase(s2);
  int c = s.compareToIgnoreCase(s3);
  int d = s2.compareToIgnoreCase("PAYAL");
  int e = s2.compareToIgnoreCase("PaYAL");
  int f = s2.compareToIgnoreCase("Payal");
  

 System.out.println("Comparing the String s and s1="+a);
 System.out.println("Comparing the String s and s2="+b);
 System.out.println("Comparing the String s and s3="+c);
 System.out.println("Comparing the String s2 and Literal="+d);
 System.out.println("Comparing the String s2 and Literal="+e);
 System.out.println("Comparing the String s2 and Literal="+f);

  
 }
}
