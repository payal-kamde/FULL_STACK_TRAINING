
public class CollectionDemo {

}
