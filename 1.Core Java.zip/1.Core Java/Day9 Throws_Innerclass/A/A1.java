abstract class Generalbank{

  abstract double gets();
  abstract double getd();
  
}
class ICICIbank extends Generalbank{
      double gets(){
	  return 4;
	  }
	  double getd(){
	  return 8.5;
	  }
}

class SBIbank extends Generalbank{

    double gets(){
	return 4;
	}
	double getd(){
	return 7;
	}
}

class A1{

   public static void main(String args[])
    {
           ICICIbank c=new ICICIbank();
           SBIbank s=new SBIbank();
		   System.out.println("the savingrate is :"+c.gets()+"%"+"the depositrate"+c.getd()+"%");
		   System.out.println("the savingrate is :"+s.gets()+"the depositrate"+s.getd());
		   
		   Generalbank g1= new ICICIbank();
		   Generalbank g2=new SBIbank();
		    System.out.println("the savingrate is :"+g1.gets()+"%"+"the depositrate"+g1.getd()+"%");
		   System.out.println("the savingrate is :"+g2.gets()+"%"+"the depositrate"+g2.getd()+"%");
		   
		   
			
   }
}