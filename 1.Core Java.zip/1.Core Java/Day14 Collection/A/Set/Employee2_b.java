import java.util.HashSet;
import java.util.Iterator;

public class Employee2_b
{

	public static void main(String[] args) 
	{
		HashSet<String> set = new HashSet<>();
		
		set.add("Medy");
		set.add("Payal");
		set.add("Sakshi");
		set.add("Piyush");
		
		Iterator<String> it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());

	}

}