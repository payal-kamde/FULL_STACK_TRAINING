public class ThreadDemo1 implements Runnable
{
 public void run()
 {
  System.out.println("Thread Started");
 }
 public static void main(String args[])
 {
   ThreadDemo t = new ThreadDemo(); 
   Thread t1 = new Thread(t);
   t.start();
 }
}