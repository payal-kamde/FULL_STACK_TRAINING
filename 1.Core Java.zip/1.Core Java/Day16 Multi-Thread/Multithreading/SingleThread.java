//Singal task using Singal Thread
public class SingleThread extends Thread
{
 public void run()
 {
 
  System.out.println("Hello Everyone");
 }
 public static void main(String args[])
 {
   SingleThread st = new SingleThread();
   st.start();
 }
}