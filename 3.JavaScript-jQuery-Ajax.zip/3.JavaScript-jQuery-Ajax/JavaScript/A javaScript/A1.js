var today = new Date();

 console.log(today);
        
        




