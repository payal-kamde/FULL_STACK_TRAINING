public class ThreadGetState extends Thread 
{  
   public void run()   
    {  
         
        Thread.State state = Thread.currentThread().getState();  
        System.out.println("Running thread name: "+ Thread.currentThread().getName());  
        System.out.println("State of thread: " + state);  
    }  
    public static void main(String args[])   
    {  
        ThreadGetState tgs1= new ThreadGetState();  
		ThreadGetState tgs2 = new ThreadGetState();
        
        tgs1.start();     
        tgs2.start();  
    }  
}  