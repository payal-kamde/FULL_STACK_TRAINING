public class Pattern4
{
	public static void main(String[] args)
	{
		int rows = Integer.parseInt(args[0]);
		int temp = 1;
		System.out.println("## Printing the pattern ##");
		for (int i = 1; i <= rows; i++)
		{
			for (int j = 1; j <= i; j++)
			{
				System.out.print(temp + " ");
				temp++;
			}
			System.out.println();
		}
	}
}