class Fibonacci
{
   public static void main(String[] args)
   {
      int a=0, b=1, c=0;
      int n = Integer.parseInt(args[0]);
      
      System.out.print("Enter the value of n: ");
     
      System.out.print("\nFibonacci Series: " +a+ " " +b+ " ");
      c = a+b;
      n = n-2;
      while(n>0)
      {
         System.out.print(c+ " ");
         a = b;
         b = c;
         c = a+b;
         n--;
      }
   }
}