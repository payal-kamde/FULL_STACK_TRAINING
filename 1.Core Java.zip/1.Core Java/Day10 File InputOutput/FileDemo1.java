import java.io.File;
class FileDemo1
{
 public static void main(String args[])
 {
   File f = new File("D:/JavaFullStackTrainning/Day10/abc.txt");
   
 }
}