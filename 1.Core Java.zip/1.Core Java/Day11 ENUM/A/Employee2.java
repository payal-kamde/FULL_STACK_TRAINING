import java.io.*;
import java.util.Scanner;
class Employee implements Serializable{
private String name;
private String department;
private String Designation;
private double salary;
	Employee(String name,String department,String Designation,Double salary)
{
	this.name=name;
	this.department = department;
	this.salary= salary;
	this.Designation=Designation;

}
	public String toString(){
	return name+ " "+department+ " " + Designation+" "+salary;
}
}
class Employee2{

	public static void main(String args[]) throws Exception{
	
        Scanner s1 = new Scanner(System.in);
        System.out.println("Enter your name:");
	    String name = s1.nextLine();
		System.out.println("Enetr your department");
		String department = s1.nextLine();
		System.out.println("Enter your Designation");
		String Designation = s1.nextLine();
		System.out.println("Enter your salary");
		double salary = s1.nextInt();
	Employee e = new Employee(name,department,Designation,salary);
	
	File f = new File("D:/JavaFullStackTrainning/Day10/cf.txt");
	f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee e1 =(Employee)ois.readObject();
		ois.close();
		System.out.println(e1);
	}
}