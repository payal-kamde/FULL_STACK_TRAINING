package animals;
public class Kangaroo implements Animal{
	public void move(){
		System.out.println("Kangaroo Hops...");
	}
	
	public void eat(){
		System.out.println("Kangaroo eats...");
	}
	
	public void sleep(){
		System.out.println("Kangaroo is sleeping");
	}
}
