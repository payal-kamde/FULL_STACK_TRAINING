import java.util.Scanner;
interface LibraryUser{
void registerAccount();
void requestBook();
}
class KidUser implements LibraryUser{
int age;
String BookType;
Scanner s = new Scanner(System.in);
public void registerAccount(){
	System.out.println("Enter your age");
	age = s.nextInt();
if(age<12){
System.out.println("you have Successfully registered under a kids account");
KidUser k = new KidUser();
k.requestBook();
}
else{
System.out.println("Sorry, Age must be less than 12 to register as a kid");
}
}
public void requestBook(){
	System.out.println("Please enter book type");
	BookType = s.nextLine();
if(BookType.equals("kids")){
System.out.println("Book issued successfully,Please return the book within 10 days");
}
else{
System.out.println("Oops, you are allowed to take only kids books");
}

}

}


class AdultUser implements LibraryUser{
int age;
String BookType;
Scanner s = new Scanner(System.in);	
public void registerAccount(){
	System.out.println("Enter your age:");
	age= s.nextInt();
if(age>12){
System.out.println("you have Successfully registered under an Adult account");
AdultUser a =new AdultUser();
a.requestBook();
}
else{
System.out.println("Sorry, Age must be greater than 12 to register as a Adult");
}
}
public void requestBook(){
	System.out.println("Please enter book type:");
	BookType = s.nextLine();
if(BookType.equals("fiction")){
System.out.println("Book issued successfully,Please return the book within 10 days");
}
else{
System.out.println("Oops, you are allowed to take only adult fiction books");
}


}
}   
class Library{
public static void main(String args[]){
KidUser kid = new KidUser();
kid.registerAccount();
kid.requestBook();

AdultUser a = new AdultUser();
a.registerAccount();
a.requestBook();

}
}