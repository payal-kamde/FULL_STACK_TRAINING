import package1.home;
class area
{
 public static void main(String args[])
 {
  home h = new  home();
  h.show();
 }
}