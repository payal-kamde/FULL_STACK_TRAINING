package com.AutoMobile.twoWheeler;

import com.AutoMobile.Vehicle;

public class Hero extends Vehicle 
{
	public int getSpeed()
	
	{
		return 100;
	}
	public void radio()
	{
		System.out.println("Radio");
	}
	
	public String getModelName()
	{
		return "HERO";
	}
	public String getRegistrationNumber()
	{
		return ""4432";
	}
	public String getOwnerName()
	{
		return "Nisha";
	}
	