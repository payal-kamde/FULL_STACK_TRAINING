package com.sms.SchoolManagementSystem.exception;

public class ConnectionUtilityException extends Exception{
	

	public ConnectionUtilityException()
	{
		
	}
	public ConnectionUtilityException(String message)
	{ 
	super(message);
		
	
	}
	public ConnectionUtilityException(Throwable cause)
	{
		super(cause);
			
	}
	public ConnectionUtilityException(String message,Throwable cause)
	{
		super(message,cause);

	}
	public ConnectionUtilityException(String message,Throwable cause,boolean enableSuppression,boolean writableStackTrace)
	{
		super(message,cause,enableSuppression,writableStackTrace);
		
}

}
