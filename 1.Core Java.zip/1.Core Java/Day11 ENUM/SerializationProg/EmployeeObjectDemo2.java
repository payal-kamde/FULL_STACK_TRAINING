import java.io.*;
class Employee implements Serializable
{
 int empId;
 String empName;
 
 Employee(int empId, String empName)
 {
  this.empId =empId;
  this.empName=empName;
 }
 
 public String toString()
 {
  return empId+ "" +empName;
 }
}

class EmployeeObjectDemo2
{
 public static void main(String args[]) throws Exception
 {
  
  File f = new File("D:/JavaFullStackTrainning/Day10/pqr.txt");
  ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
  Employee e = (Employee)ois.readObject();
  ois.close();
 }
}