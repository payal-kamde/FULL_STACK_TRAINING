public class EnumDemo
{
 enum Direction
 {
  EAST(10),WEST(20),NORTH(30),SOUTH(40);
  int val;
  Direction(int val)
  {
   this.val=val;
  }
 }
 public static void main(String args[])
 {
  for(Direction d:Direction.values())
  {
   System.out.println(d+ " " +d.val);
  }
 }
}