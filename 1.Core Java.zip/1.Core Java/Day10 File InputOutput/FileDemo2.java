import java.io.File;
class FileDemo2
{
 public static void main(String args[])
 {
   File f = new File("D:/JavaFullStackTrainning/Day10/abc.txt");
   System.out.println(f.getName());
 }
}