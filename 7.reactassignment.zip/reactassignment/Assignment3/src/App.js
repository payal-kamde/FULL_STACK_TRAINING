import logo from './logo.svg';
import './App.css';
import Bigimage from './view/Bigimage';
import Content1 from './view/Content1';
import Content2 from './view/Content2';




function App() {
  return (
    <div className='RightPane'>

    <div className='Bigimage'>

      <Bigimage/>

    </div>

    <div className='Contentbox'>

      <div className='Content1'>

        <Content1/>

      </div>

      <div>

        <Content2/>

      </div>

    </div>

  </div>



  )

}

export default App;
