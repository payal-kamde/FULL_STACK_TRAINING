class Table
{
 public static void main(String args[])
 {
  int n = Integer.parseInt(args[0]);
  int c;
  for(int a=1;a<=10;a++)
  {
  c = a*n;
  System.out.print("\t" +c);
   
  }
 }
}