import{
    AUTH_GET_PERMISSIONS,
    AUTH_LOGIN,
    AUTH_LOGOUT,
    AUTH_ERROR,
    AUTH_CHECK,
} from 'react-admin';
import{ createBrowserHistory } from "history";
//create history
const history = createBrowserHistory();

const homepage=()=>{

    history.push('/home');
}

export default (type, params,props)=>{
    if(type == AUTH_LOGIN){
        const{ username, password} = params;
        //create auth for simple user
        if(username === 'user' && password === 'password'){
            localStorage.setItem('role','user');
            localStorage.removeItem('not_authenticated');
            homepage();
            return Promise.resolve();

            }
        
        // crete auth for admin
            if(username === 'admin' && password === 'password'){
            localStorage.setItem('role', 'admin');
            localStorage.removeItem('not_authenticaticated');
            return Promise.resolve();

        }
        localStorage.setItem('role', 'admin');
        return Promise.reject();

    }
    if(type === AUTH_LOGOUT) {

    }
}