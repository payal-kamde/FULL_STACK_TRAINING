class A{}
class DemoForName
{
 public static void main(String args[])throws Exception
 {
  Class c = Class.forName("A");
  System.out.println(c.getName());
 }
}