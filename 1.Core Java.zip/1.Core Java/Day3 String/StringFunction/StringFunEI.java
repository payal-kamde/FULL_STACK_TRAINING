class StringFunEI
{
 public static void main(String args[])
 {
 String s = "PAyAl";
  String s1 = "paYaL";

 System.out.println(s.equalsIgnoreCase(s1));
 
  String s2 = "POyAl";
  String s3 = "paYaL";
  System.out.println(s2.equalsIgnoreCase(s3));
  
 }
}