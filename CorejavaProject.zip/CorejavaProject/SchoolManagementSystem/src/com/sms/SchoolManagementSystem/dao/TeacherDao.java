package com.sms.SchoolManagementSystem.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sms.SchoolManagementSystem.bin.StudentBin;
import com.sms.SchoolManagementSystem.bin.TeacherBin;

public class TeacherDao {
	
	String dbURL = "jdbc:mysql://localhost:3306/SchoolManagementSystem";
	String username = "root";
	String password = "root";
	
	Connection conn=null;

	public int insertTeacher(TeacherBin teacherBin) throws SQLException 
	{
		int rowsInserted=0;
		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    String sql = "INSERT INTO Teacher (teacherid, name, gender, salary) VALUES (?, ?, ?, ?)";
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setInt(1, teacherBin.getTId());
		    statement.setString(2, teacherBin.getTName());
		    statement.setString(3, teacherBin.getTGender());
		    statement.setInt(4, teacherBin.getTSalary());
		     rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0)
		    {
		        System.out.println("A new user was inserted successfully!");
		    }
		} 
		catch (SQLException ex) 
		{
		    ex.printStackTrace();
		}
		finally {
			conn.close();
		}
		return rowsInserted;
	}
	
	public int updateTeacher(TeacherBin teacherBin, int techId) throws SQLException 
	{
		int rowsInserted=0;
		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
//		    String sql = "INSERT INTO Teacher (teacherid, name, gender, salary) VALUES (?, ?, ?, ?)";
		    String sql = "update Teacher set teacherid=?,name=?,gender=?,salary=? where empid=?";
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setInt(1, teacherBin.getTId());
		    statement.setString(2, teacherBin.getTName());
		    statement.setString(3, teacherBin.getTGender());
		    statement.setInt(4, teacherBin.getTSalary());
		    statement.setInt(5, techId);
		     rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0)
		    {
		        System.out.println("A new user was inserted successfully!");
		    }
		} 
		catch (SQLException ex) 
		{
		    ex.printStackTrace();
		}
		finally {
			conn.close();
		}
		return rowsInserted;
	}
	
	public int deleteTeacher(int id) throws SQLException 
	{
		int rowsInserted=0;
		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
		    String sql = "delete from Teacher where empid=?";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setInt(1, id);
		     
		     rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0)
		    {
		        System.out.println("A new user was inserted successfully!");
		    }
		} 
		catch (SQLException ex) 
		{
		    ex.printStackTrace();
		}
		finally {
		
			
			conn.close();
		}
		
		return rowsInserted;
	}
	
	public TeacherBin showTeacher(int id) throws SQLException 
	{
		TeacherBin stu = null;
		int rowsInserted=0;
//		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
//			    String sql = "INSERT INTO Teacher (teacherid, name, gender, salary) VALUES (?, ?, ?, ?)";
		    String sql = "select * from Teacher where empid="+id;
		    
		    Statement statement = conn.createStatement();
		    ResultSet result = statement.executeQuery(sql);
		     
		    int count = 0;
		     
		    while (result.next()){
		    	int teacherid = result.getInt("teacherid");
		        String name = result.getString("name");
		        String gender = result.getString("gender");
		        int salary = result.getInt("salary");
		        
		        stu = new TeacherBin();
		        stu.setTId(teacherid);
		        stu.setTGender(gender);
		        stu.setTName(name);
		        
		    }
		
		return stu;
	}
	
	public List<TeacherBin> showAllTeacher() {
		TeacherBin stu = null;
		List stulist = new ArrayList();
		int rowsInserted=0;
//		try {
		     try {
				conn = DriverManager.getConnection(dbURL, username, password);
			
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
		    String sql = "select * from Teacher";
		    
		    Statement statement = conn.createStatement();
		    ResultSet result = statement.executeQuery(sql);
		     
		    int count = 0;
		    
		    while (result.next()){
		    	int teacherid = result.getInt("teacherid");
		        String name = result.getString("name");
		        String gender = result.getString("gender");
		        int salary = result.getInt("salary");
		     
//		        String output = "User #%d: %s - %s - %s - %s";
		        stu = new TeacherBin();
		        stu.setTId(salary);;
		        stu.setTGender(gender);
		        stu.setTName(name);
		        stu.setTSalary(salary);;
		        stulist.add(stu);
		    }
		     } catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
		return stulist;
	}
	
	
}
