package newPackage;
public class Teacher
{
    private String t_name ;
	private int t_id;
	private  char t_gender;
	private int t_salary;
	
	
	
	public Teacher()
	{
	 this.t_name=t_name;
	 this.t_id=t_id;
	 this.t_gender=t_gender;
	 this.t_salary=t_salary;
		
	}
	
	public void setTName(String t_name)
	{
		this.t_name=t_name;
		
	}
	public void setTId(int t_id)
	{ 
	    this.t_id=t_id;
	}
	public void setTGender(char t_gendergender)
	{
		this.t_gender=t_gender;
	}
	public void setTSalary(int t_salary)
	{
		this.t_salary=t_salary;
	}
	
	public String getTName()
	{
		return t_name;
	}
	public int getTId()
	{
		return t_id;
	}
	public char getTGender()
	{
		return t_gender;
	}
	public int getTSalary()
	{
		return t_salary;
	}



  
  
}  