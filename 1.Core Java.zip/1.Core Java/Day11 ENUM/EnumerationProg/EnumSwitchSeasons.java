class EnumSwitchSeasons
{
enum Seasons
{
Winter(1),Spring(2),Summer(3),Autumn(4);
int val;
Seasons(int i)
{
this.val=i;
}
}
public static void main(String gg[])
{
Seasons s=Seasons.Winter;
switch(s)
{
case Winter:
System.out.println(s.ordinal());
System.out.println(s.val);
break;
case Spring:
System.out.println(s.ordinal());
System.out.println(s.val);
break;
case Summer:
System.out.println(s.ordinal());
System.out.println(s.val);
break;
case Autumn:
System.out.println(s.ordinal());
System.out.println(s.val);
break;
}

}
}
