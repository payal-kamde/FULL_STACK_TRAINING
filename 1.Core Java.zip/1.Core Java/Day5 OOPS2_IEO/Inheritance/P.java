//    Hierarchical inheritance

class P
{
 void displayP()
 {
  System.out.println("P class");
  
 }
}
class Q extends P
{
 void displayQ()
 {
  System.out.println("Q class");
 }
}
class R extends P
{
 void displayR()
 {
  System.out.println("R class");
 }
 public static void main(String args[])
 {
  P ob1 = new P();
  ob1.displayP();
  
   Q ob2 = new Q();
  ob2.displayP();
  ob2.displayQ();
  
   R ob3 = new R();
  ob3.displayP();
  //ob3.displayQ();
  ob3.displayR();
 }
}