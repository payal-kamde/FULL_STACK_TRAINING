package com.yash.LifeCycleBeanXIA;

import javax.naming.spi.InitialContextFactoryBuilder;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Interface implements InitializingBean,DisposableBean {
private double price;

public Interface() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Mobile [price=" + price + "]";
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public void afterPropertiesSet() throws Exception {
System.out.println("this is initizlization  using interface for example Mobile");	
}

public void destroy() throws Exception {
System.out.println("by exit");	
}


}

