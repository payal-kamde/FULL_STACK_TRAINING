//set name sand get name mettod multipalthreads ,,,,,,priority() method

public class ThreadNamePriority extends Thread
{
 public void run()
 {
	 System.out.println("In run method");
	  System.out.println(Thread.currentThread().getPriority());
 }
 public static void main(String args[])
 {
  System.out.println(Thread.currentThread().getPriority());
  Thread.currentThread().setPriority(MIN_PRIORITY);
  System.out.println(Thread.currentThread().getPriority());
  
  ThreadNamePriority tp = new ThreadNamePriority();
  tp.setPriority(1);
  tp.start();
  
 }
}