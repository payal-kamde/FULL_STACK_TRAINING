class This3
{
 This3()
 {
 System.out.println("no argument constructor");
 
 }
 This3(int a)
 {
  this();
  System.out.println("Parameterised constructor");
 }
 public static void main(String args[])
 {
  This3 t = new This3(10);
 }
}