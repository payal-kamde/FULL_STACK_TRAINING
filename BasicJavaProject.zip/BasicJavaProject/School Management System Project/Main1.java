import newPackage.Student;
import newPackage.Teacher;
import newPackage.School;
import java.util.Scanner;

class Main1
{
 public static void main(String args[])
 {
   Scanner input = new Scanner(System.in);

	   System.out.print("Enter your choice: ");
       String Student= input.nextLine();
       System.out.println("My choice is: " + Student);
       input.close();
  
   
   
   
   Student s = new Student();
   s.setName("Sakshi");
   System.out.println("Student Name:" +s.getName());
   s.setRolln(101);
   System.out.println("Student Roll Number:" +s.getRolln());
   s.setGender('F');
   System.out.println("Student Gender:" +s.getGender());
   s.setFees(30000);
   System.out.println("Student Fees:" +s.getFees());
   
   Teacher th = new Teacher();
   th.setTName("Sameer Mina");
   System.out.println("Teacher Name:" +th.getTName());
   th.setTId(11);
   System.out.println("Teacher ID:" +th.getTName());
   th.setTGender('M');
   System.out.println("Teacher Gender:" +th.getTGender());
   th.setTSalary(70000);
   System.out.println("Teacher Salary:" +th.getTSalary());
   
   
   
   School sh = new School();
   sh.setSName("Sankalp Higher Scondary School");
   System.out.println("School Name:" +sh.getSName());
   
   sh.setClasses(7);
   System.out.println("School classes:" +sh.getClasses());
   
   sh.setPlayGround("cricket");
   System.out.println("School Play Ground:" +sh.getPlayGround());
   
   
   
 }
}