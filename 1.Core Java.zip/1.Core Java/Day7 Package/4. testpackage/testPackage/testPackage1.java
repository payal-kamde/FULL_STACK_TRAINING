import testPackage.Foundation;
public class testPackage1{
	public static void main(String[] args){
		Foundation f = new Foundation();
		//System.out.println(f.var1); // private access error
		//System.out.println(f.var2); // not public error (default in base class)
		//System.out.println(f.var3); // protected access error
		System.out.println(f.var4); // Accessible
	}
}