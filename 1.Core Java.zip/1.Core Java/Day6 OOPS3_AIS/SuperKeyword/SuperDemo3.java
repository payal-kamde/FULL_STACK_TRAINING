class A
{
 A()
 {
  System.out.println("I am in class A constructor");
 }
}
 class SuperDemo3 extends A
 {
  SuperDemo3()
  {
   System.out.println("I am in SuperDemo3 constructor");
  }
  
   public static void main(String args[])
   {
	   
	   SuperDemo3 sd = new SuperDemo3();
   }
 }
 
