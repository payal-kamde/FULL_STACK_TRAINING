class Test2
{  
  public static void main(String args[])
  {  
   Class c = char.class;   
   System.out.println(c.getName());  
  
   Class c2 = Test2.class;   
   System.out.println(c2.getName());  
 }  
}  