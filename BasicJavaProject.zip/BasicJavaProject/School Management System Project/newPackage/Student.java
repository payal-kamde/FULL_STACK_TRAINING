package newPackage;
public class Student
{
    private String name ;
	private int rolln;
	private  char gender;
	private int fees;
	
	
	
	public Student()
	{
	 this.name=name;
	 this.rolln=rolln;
	 this.gender=gender;
	 this.fees=fees;
		
	}
	
	public void setName(String name)
	{
		this.name=name;
		
	}
	public void setRolln(int rolln)
	{
		this.rolln=rolln;
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
	public void setFees(int fees)
	{
		this.fees=fees;
	}
	
	public String getName()
	{
		return name;
	}
	public int getRolln()
	{
		return rolln;
	}
	public char getGender()
	{
		return gender;
	}
	public int getFees()
	{
		return fees;
	}



  
  
}  