class StringFunE
{
 public static void main(String args[])
 {
 String s = "I am very Happy";
  String s1 = "I am very Happy";
 String s2 = new String("I am busy");
 


  System.out.println(s.equals(s1));
   System.out.println(s.equals(s2));
 }
}