import java.util.HashSet;
import java.util.Iterator;

// Vector, lInkedlist,  stack
class HashSetExample1
{
 public static void main(String[] args)
 {
   HashSet<String> h1 = new HashSet<>();
		
   h1.add("10");
   h1.add("20");
   h1.add("30");
		
  Iterator itr = h1.iterator();
  while(itr.hasNext())
  {
    System.out.println(itr.next() + " ");
  }
   h1.remove("30");
   h1.add("40");
   h1.add("50");
   System.out.println(h1);
 }
}