import java.util.ArrayList;
class CollectionArrayList 
{
public static void main(String[] args)
{
ArrayList<Integer> n = new ArrayList<Integer>();
n.add(23);
n.add(32);
n.add(45);
n.add(63);
System.out.println(n);
for(Integer i:n)
{
 System.out.println(i);
}
}
}

