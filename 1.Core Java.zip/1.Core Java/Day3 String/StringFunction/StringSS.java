class StringSS
{
 public static void main(String args[])
 {
  String s = "Payal Kamde";
  System.out.println("Original String:"+s);
  System.out.println(s.substring(6));
  System.out.println(s.substring(0,6));
 }
 
}