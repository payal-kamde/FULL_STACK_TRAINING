
// Encapsulation
class Employee1
{
 private int emp_id;
 public void setImpId(int emp_id)
 {
  this.emp_id=emp_id;
 }
 public int getEmpId()
 {
  return emp_id;
 }
}
 class Organization
 {
  public static void main(String args[])
  {
   Employee e = new Employee();
   e.setImpId(1000);
   System.out.println(e.getEmpId());
  }
 }
