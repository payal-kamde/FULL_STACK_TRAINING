package com.sms.SchoolManagementSystem.exception;

public class DaoInputException {

}
