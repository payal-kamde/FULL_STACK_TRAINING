package com.sms.SchoolManagementSystem.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sms.SchoolManagementSystem.bin.StudentBin;

public class StudentDao {
	
	String dbURL = "jdbc:mysql://localhost:3306/SchoolManagementSystem";
	String username = "root";
	String password = "root";
	
	Connection conn=null;

	public int insertStudent(StudentBin studentBin) throws SQLException 
	{
		int rowsInserted=0;
		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
		    String sql = "INSERT INTO student (rollno, name, gender, fees) VALUES (?, ?, ?, ?)";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setInt(1, studentBin.getRolln());
		    statement.setString(2, studentBin.getName());
		    statement.setString(3, studentBin.getGender());
		    statement.setInt(4, studentBin.getFees());
		     
		     rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0)
		    {
		        System.out.println("A new user was inserted successfully!");
		    }
		} 
		catch (SQLException ex) 
		{
		    ex.printStackTrace();
		}
		finally {
		
			
			conn.close();
		}
		
		return rowsInserted;
	}
	
	public int updateStudent(StudentBin studentBin,int id) throws SQLException 
	{
		int rowsInserted=0;
		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
//		    String sql = "INSERT INTO student (rollno, name, gender, fees) VALUES (?, ?, ?, ?)";
		    String sql = "update student set rollno=?,name=?,gender=?,fees=? where studentid=?";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setInt(1, studentBin.getRolln());
		    statement.setString(2, studentBin.getName());
		    statement.setString(3, studentBin.getGender());
		    statement.setInt(4, studentBin.getFees());
		    statement.setInt(5, id);
		     
		     rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0)
		    {
		        System.out.println("A new user was inserted successfully!");
		    }
		} 
		catch (SQLException ex) 
		{
		    ex.printStackTrace();
		}
		finally {
		
			
			conn.close();
		}
		
		return rowsInserted;
	}
	
	public int deleteStudent(int id) throws SQLException 
	{
		int rowsInserted=0;
		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
//		    String sql = "INSERT INTO student (rollno, name, gender, fees) VALUES (?, ?, ?, ?)";
		    String sql = "delete from student where studentid=?";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setInt(1, id);
		     
		     rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0)
		    {
		        System.out.println("A new user was inserted successfully!");
		    }
		} 
		catch (SQLException ex) 
		{
		    ex.printStackTrace();
		}
		finally {
		
			
			conn.close();
		}
		
		return rowsInserted;
	}
	
	
	public StudentBin showStudent(int id) throws SQLException 
	{
		StudentBin stu = null;
		int rowsInserted=0;
//		try {
		     conn = DriverManager.getConnection(dbURL, username, password);
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
//		    String sql = "INSERT INTO student (rollno, name, gender, fees) VALUES (?, ?, ?, ?)";
		    String sql = "select * from student where studentid="+id;
		    
		    Statement statement = conn.createStatement();
		    ResultSet result = statement.executeQuery(sql);
		     
		    int count = 0;
		     
		    while (result.next()){
		    	String studentid = result.getString("studentid");
		        int rollno = result.getInt("rollno");
		        String name = result.getString("name");
		        String gender = result.getString("gender");
		        int fees = result.getInt("fees");
		     
//		        String output = "User #%d: %s - %s - %s - %s";
		        stu = new StudentBin();
		        stu.setFees(fees);
		        stu.setGender(gender);
		        stu.setName(name);
		        stu.setRolln(rollno);
		        
		    }
		
		return stu;
	}

	public List<StudentBin> showAllStudent() {
		StudentBin stu = null;
		List stulist = new ArrayList();
		int rowsInserted=0;
//		try {
		     try {
				conn = DriverManager.getConnection(dbURL, username, password);
			
			    if (conn != null) 
			    {
			        System.out.println("Connected");
			    }
		    
//		    String sql = "INSERT INTO student (rollno, name, gender, fees) VALUES (?, ?, ?, ?)";
		    String sql = "select * from student";
		    
		    Statement statement = conn.createStatement();
		    ResultSet result = statement.executeQuery(sql);
		     
		    int count = 0;
		    
		    while (result.next()){
		    	String studentid = result.getString("studentid");
		        int rollno = result.getInt("rollno");
		        String name = result.getString("name");
		        String gender = result.getString("gender");
		        int fees = result.getInt("fees");
		     
//		        String output = "User #%d: %s - %s - %s - %s";
		        stu = new StudentBin();
		        stu.setFees(fees);
		        stu.setGender(gender);
		        stu.setName(name);
		        stu.setRolln(rollno);
		        stulist.add(stu);
		    }
		     } catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
		return stulist;
	}
	
}
