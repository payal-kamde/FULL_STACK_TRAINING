import java.io.*;
import java.util.Scanner;

public class CountJTextF{
    public static void main(String[] args)throws IOException
    {

        String fileName = "D:/JavaFullStackTrainning/Day10/abc.txt";
        String line = "";
        Scanner scanner = new Scanner(new FileReader(fileName));
		
		//Scanner input = new Scanner(System.in);

		
        try {

          while ( scanner.hasNextLine() ){
            line = scanner.nextLine();
            int counter = 0;
            for( int i=0; i<line.length(); i++ )
			{   				
                if( line.charAt(i) == 'j' ) 
				{
                    counter++; 

                } 


            }

             System.out.println(counter);   
          }
        }
        finally 
		{

          scanner.close();
        }
    }
}