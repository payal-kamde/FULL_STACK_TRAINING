class SumAveArray1
{
 public static void main(String args[])
 {
  int[][] a , b = {{10,20,30,40,50}{6,4,5,3,8}};
  int sum=0;
  int avg=0;
  
  System.out.println("Print the all the element");
  
  
  for(int i=0;i<a.length;i++)
  {
   for(int j=0;j<i,j++)
   {
   sum=sum+a[i]b[j];
   }
  
  System.out.println(sum);
   avg=sum/5;
  System.out.println(avg);
  }
}
}


