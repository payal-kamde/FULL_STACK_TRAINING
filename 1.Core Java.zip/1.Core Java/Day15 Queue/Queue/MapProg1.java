import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapProg1
{
 public static void main(String args[])
{
  Map<Integer,String> map = new HashMap<Integer,String>();
  map.put(10,"yash");
  map.put(11,"Technologies");
  map.put(12,"Payal");
  
 for(Map.Entry m:map.entrySet())
{
 System.out.println("key: " +m.getKey()+ " value: "+m.getValue());
}

}
}