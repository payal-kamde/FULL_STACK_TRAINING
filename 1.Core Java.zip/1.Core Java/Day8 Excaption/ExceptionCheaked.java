import java.io.FileInputStream;
class ExceptionCheaked
{
 public static void main(String args[])
 {
     //FileInputStream f = new FileInputStream("D:/xyz.text");
	 
	 try
	 {
		// String s = null;
	 // System.out.println(s.enght());
	  System.out.println("Hello");
	  
	 }
	 catch(Exception e)
	 {
		 System.out.println(e);
	 }
	 System.out.println("bye");
  
 }
}