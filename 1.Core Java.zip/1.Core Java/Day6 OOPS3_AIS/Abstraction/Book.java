abstract class Book
{
 abstract void read();
}
class Motivation extends Book
{
 void read()
 {
  System.out.println("read the motivation book");
 }
}

class History extends Book
{
  void read()
 {
  System.out.println("read the History book");
 }
 
 public static void main(String args[])
 {

  
   Motivation m = new Motivation();
   m.read();
   
   History h = new History();
   h.read();
 }
}
