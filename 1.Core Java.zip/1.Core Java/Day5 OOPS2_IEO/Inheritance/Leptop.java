class Leptop
{
 void work()
 {
  System.out.println("Leptop is working");
 }
}
class HP extends Leptop
{
 public static void main(String args[])
 {
  HP h = new HP();
  h.work();
 }
}