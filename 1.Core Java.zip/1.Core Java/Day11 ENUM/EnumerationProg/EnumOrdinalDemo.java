class EnumOrdinalDemo
{
 enum Directions
 {
  EAST,WEST,NORTH,SOUTH;
 }
 public static void main(String args[])
 {
  for(Direction d:Direction.values())
 }
}