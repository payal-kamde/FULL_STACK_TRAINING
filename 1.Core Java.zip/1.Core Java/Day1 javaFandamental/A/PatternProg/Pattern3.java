class Pattern3
{
	public static void main(String[] args)
	{
		int rows = Integer.parseInt(args[0]);
		System.out.println("## Printing the pattern ##");
		for (int i = 1; i <= rows; i++) 
                {
                        for (int j = rows; j >= i; j--)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}