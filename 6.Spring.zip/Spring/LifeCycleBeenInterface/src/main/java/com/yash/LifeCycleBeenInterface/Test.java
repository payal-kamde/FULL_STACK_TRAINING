package com.yash.LifeCycleBeenInterface;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test {
	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		
		
		System.out.println("---------------Interface----------------------");
		Interface p = context.getBean("p1", Interface.class);
		System.out.println(p);


		
	    

	}
}
