class Palindrome
{  
   public static void main(String[] args) 
   {  
       int num= Integer.parseInt(args[0]);
       int r,sum=0;
       int temp=num;    
       while(num>0)
       {    
       r=num%10;    
       sum=(sum*10)+r;    
       num=num/10;    
       }    
        if(temp==sum)    
        System.out.println("The entered number is a palindrome number:" +temp);    
        else    
        System.out.println("The entered number is not a palindrome:" +temp);    
  }  
} 
