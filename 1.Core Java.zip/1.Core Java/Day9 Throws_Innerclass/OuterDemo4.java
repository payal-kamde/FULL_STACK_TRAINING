//if inner class is static , it can not  access outer class members
//yes
class Outer
{
 void show1()
 {
  System.out.println("Outer Show1");
 }
  static class Inner
 {
  void show()
  {
   System.out.println("Outer Show");
  }
 }
}

public class OuterDemo4
{
 public static void main(String args[])
 {
   Outer o=new Outer();
   o.show1();
   Outer.Inner oi =new Outer.Inner();
   oi.show();
 }
}