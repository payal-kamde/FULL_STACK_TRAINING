package com.sms.SchoolManagementSystem.exception;

public class InpuFormateException {

}
