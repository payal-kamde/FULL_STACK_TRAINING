import java.util.Scanner;
class StrLaFi
{
 public static void main(String args[])
 { 
  Scanner s = new Scanner(System.in);
  String a = s.nextLine();
  String result="";
  String arrInput[] = a.split("");
  for(int i=1;i<(arrInput.length-1);i++)
  {
   result = result+arrInput[i];
  }
   System.out.println(result);
 }
 
}