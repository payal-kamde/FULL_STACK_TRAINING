//set name sand get name mettod multipalthreads

public class ThreadNameDemo1 extends Thread
{
 public void run()
 {
	 Thread.currentThread().setName("Run");
	 System.out.println("Run : " +Thread.currentThread().getName());
 }
 public static void main(String args[])
 {
  System.out.println(Thread.currentThread().getName());//main()
  ThreadNameDemo1 t1 = new ThreadNameDemo1();
  t1.setName("T1 thread");
  t1.start();
  
  ThreadNameDemo1 t2 = new ThreadNameDemo1();
  t1.setName("T2 thread");
  t2.start();
  
 }
}