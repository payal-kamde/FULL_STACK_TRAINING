abstract class vehicle
{
 abstract void start();
}
class Car extends vehicle
{
 void start()
 {
  System.out.println("Start by Self/key");
 }
}

class Bike extends vehicle
{
  void start()
 {
  System.out.println("Start by kick");
 }
 
 public static void main(String args[])
 {
  //vehicle v = new vehicle();
  
   Car c = new Car();
   c.start();
   
   Bike b = new Bike();
   b.start();
 }
}
