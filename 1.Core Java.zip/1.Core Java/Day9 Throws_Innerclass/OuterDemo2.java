//non-static inner class
class Outer
{
 class Inner
 {
  void show()
  {
   System.out.println("Outer Show");
  }
 }
}

public class OuterDemo2
{
 public static void main(String args[])
 {
  Outer o=new Outer();
  Outer.Inner oi = o.new Inner();
  oi.show();
 }
}