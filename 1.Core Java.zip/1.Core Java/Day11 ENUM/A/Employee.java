import java.io.*;
class Employee implements Serializable
{
 private String name;
 private String department;
 private String designation;
 private double salary; 
 
 public void setName(String name)
 {
  this.name=name;
 }
 public void setDepartment(String department)
 {
  this.department=department;
 }
 public void setDesignation(String designation)
 {
  this.designation=designation;
 }
 public void setSalary(double salary)
 {
  this.salary=salary;
 }
  public String getName()
 {
  return name;
 }
  public String getDepartment()
 {
  return department;
 }
 public String getDesignation()
 {
  return designation;
 }
  public double getSalary()
 {
  return salary;
 }
 public static void main(String args[]) throws Exception
 {
	 Employee e = new Employee();
	 e.setName("Payal");
	 e.setDepartment("IT");
	 e.setDesignation("Java full Stack trainee");
	 e.setSalary(10000.00);
	 
	 File f = new File("D:/JavaFullStackTrainning/Day10/hp.txt");
	 f.createNewFile();
	 
	 ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
	 oos.writeObject(e);
	 ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
	 Employee e1=(Employee) ois.readObject();
	 
	 System.out.println("Empoyee Name:"+e1.getName());
	 System.out.println("Empoyee Department:"+e1.getDepartment());
	 System.out.println("Empoyee Designation:"+e1.getDesignation());
	 System.out.println("Empoyee Salary:"+e1.getSalary());
	 
	 oos.close();
	 ois.close();
 }
 
}