package yash.com.spring.Lifecylebean.xml;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Annotation {
private String type;

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

@Override
public String toString() {
	return "Samosa [type=" + type + "]";
}

public Annotation() {
	super();
	// TODO Auto-generated constructor stub
}
@PostConstruct
public void init() {
	System.out.println("this is a annotation init method");
	
}
@PreDestroy
public void end()
{
	System.out.println("end of annotation");
}
}
