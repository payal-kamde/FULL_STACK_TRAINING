class Outer
{
 static class Inner
 {
  void show()
  {
   System.out.println("Outer Show");
  }
 }
}

public class OuterDemo
{
 public static void main(String args[])
 {
  //Outer.o=new Outer();
  Outer.Inner oi = new Outer.Inner();
  oi.show();
 }
}