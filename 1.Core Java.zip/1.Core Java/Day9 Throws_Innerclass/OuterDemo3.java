//if inner class is nonstatic , it can access outer class member
//yes
class Outer
{
 void show1()
 {
  System.out.println("Outer Show1");
 }
  class Inner
 {
  void show()
  {
   System.out.println("Outer Show");
  }
 }
}

public class OuterDemo3
{
 public static void main(String args[])
 {
  Outer o=new Outer();
  o.show1();
  Outer.Inner oi =o.new Inner();
  oi.show();
 }
}