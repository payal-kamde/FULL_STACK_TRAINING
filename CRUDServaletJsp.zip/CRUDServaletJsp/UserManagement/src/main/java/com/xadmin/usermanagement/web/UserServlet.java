package com.xadmin.usermanagement.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String country = req.getParameter("country");
		int num=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/userdb";
			String user = "root";
			String pass = "root";

			Connection con = DriverManager.getConnection(url,user,pass);
			String quary1 = "insert into users(name,email,country) values(?,?,?)";
			PreparedStatement praps = con.prepareStatement(quary1);
			praps.setString(1, name);
			praps.setString(2, email);
			praps.setString(3, country);
			num=praps.executeUpdate();
			
			if(num>0) {
				req.getRequestDispatcher("showtable.jsp").forward(req, res);
				
			}
			else {
				req.getRequestDispatcher("Error.jsp").forward(req, res);
				
			}

			con.close();
			} catch (Exception e) {
			e.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
