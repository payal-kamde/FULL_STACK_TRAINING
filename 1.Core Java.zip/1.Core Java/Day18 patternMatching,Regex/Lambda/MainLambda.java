
public class MainLambda
{
  public static void main(String args[])
  {
    MainLambda lamda = ()->{
	System.out.println("Hye Lambda");
  };
 }
}
