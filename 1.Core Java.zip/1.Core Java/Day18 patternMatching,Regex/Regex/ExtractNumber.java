public class ExtractNumber
{
 public static void main(String args[])
 {
   String sInput1 = "Hi payal 18";
   String sInput2 = "hello 07";
   
   System.out.println("The Number part is: "+sInput1.replaceAll("[^0-9]",""));
   System.out.println("The Number part is: "+sInput2.replaceAll("[^0-9]",""));
   
 }

}