public class Factorial
{
    public static void main(String []args)
    {
       int n= Integer.parseInt(args[0]);
       int f=1;
        System.out.print("\n Factorial of "+n+" is: ");
 
        
        for(int i=1; i<=n; i++)
        {
        f*=i;
        }
 
        System.out.println(f);
 
        }
}
 