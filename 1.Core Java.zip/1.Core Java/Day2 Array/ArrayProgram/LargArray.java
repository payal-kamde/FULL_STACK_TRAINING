class LargArray
{
 public static void main(String args[])
 {
  int array[] = {8,5,9,4,1,7};
  System.out.println("Enter all the element");
  for(int i=0;i<array.length;i++)
  {
  
  }
  int larg1,larg2,temp;
  larg1=array[0];
  larg2=array[1];
  
  if (larg1<larg2)
  {
   temp=larg1;
   larg1= larg2;
   larg2= temp;
  }
  
  for(int i=2; i<array.length;i++)
  {
   if(array[i]>larg1)
   {
    larg2=larg1;
	larg1=array[i];
   }
   else if(array[i]>larg2 && array[i]!=larg1)
   {
     larg2=array[i];
   }
  }
   System.out.println("The First largest is"+larg1);
   System.out.println("The second largest is"+larg2);
 }
}