  
import java.time.LocalDate;
import java.time.LocalTime;  
import java.time.*;  
import java.time.temporal.ChronoUnit;  
import java.time.temporal.*;  
import java.time.Clock;  
import java.time.ZonedDateTime;
import java.time.DayOfWeek; 

public class LocalDateTimeEx4
{  
  public static void main(String[] args)
  {  
    LocalDate date = LocalDate.of(2022, 4, 11);  
	System.out.println(date);
    LocalTime time = LocalTime.now();  
    System.out.println(time); 

 	ZoneId zone1 = ZoneId.of("Asia/Kolkata");  
    ZoneId zone2 = ZoneId.of("Asia/Tokyo");  
    LocalTime time1 = LocalTime.now(zone1);  
    System.out.println("India Time Zone: "+time1);  
    LocalTime time2 = LocalTime.now(zone2);  
    System.out.println("Japan Time Zone: "+time2);  
    long hours = ChronoUnit.HOURS.between(time1, time2);  
    System.out.println("Hours between two Time Zone: "+hours);  
    long minutes = ChronoUnit.MINUTES.between(time1, time2);  
	
	MonthDay month = MonthDay.now();  
    ValueRange r1 = month.range(ChronoField.MONTH_OF_YEAR);  
    System.out.println(r1);  
    ValueRange r2 = month.range(ChronoField.DAY_OF_MONTH);  
    System.out.println(r2);  
	
	 Clock c = Clock.systemDefaultZone();      
    System.out.println(c.getZone());  
	
	
	ZonedDateTime zone = ZonedDateTime.parse("2022-04-11T04:49:10+05:30[Asia/Kolkata]");  
    System.out.println(zone); 
	
	 DayOfWeek day = DayOfWeek.of(1);  
    System.out.println(day.name());  
    System.out.println(day.ordinal());  
    System.out.println(day.getValue());  
	
  }  
} 