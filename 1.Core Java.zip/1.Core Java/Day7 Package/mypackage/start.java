package mypackage;
public class start
{
 public void display()
 {
  System.out .println("I am in dispaly-start  class");
 }
}