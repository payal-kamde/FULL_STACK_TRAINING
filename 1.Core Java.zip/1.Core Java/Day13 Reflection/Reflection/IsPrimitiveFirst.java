package com.logicbig.example.clazz;

public class IsPrimitiveFirst
{

    public static void main(String... args) 
	{
        boolean b = int.class.isPrimitive();
        System.out.println(b);

        b = int[].class.isPrimitive();
        System.out.println(b);

        b = Integer.class.isPrimitive();
        System.out.println(b);
    }
}