class TwoDArray
{
 public static void main(String args[])
 {
  int[][] a=new int[2][];
  //System.out.println(a);
  //System.out.println(a[0]);
  //  System.out.println(a[0][0]);
	//  System.out.println(a.length);
	   System.out.println(a[a][a].length);
 }
}