import java.util.Stack;
import java.util.Iterator;

class StackExample1
{
 public static void main(String[] args)
 {
   Stack<String> s1 = new Stack<>();
        s1.push("10");
	s1.push("20");
	s1.push("30");
		
	Iterator itr = s1.iterator();
        
      while(itr.hasNext())
     {
      System.out.print(itr.next() + " ");
     }
		
	System.out.println("");
	System.out.println(s1.pop());
	System.out.println(s1.peek());
	System.out.println(s1);
 }
}