import java.util.*;
class patient
{
	String patientName;
	double height;
	double weight;
	patient()
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Enter your Name:");
		patientName=in.nextLine();
		
		System.out.println("Enter your height");
		height=in.nextDouble();
		
		System.out.println("Enter your weight");
		weight=in.nextDouble();
	}
	void BMI()
	{
		double bmi;
		bmi=(weight/(height*height))*703;
		System.out.println("You entered string"+patientName);
		System.out.println("You entered weight"+weight);
		System.out.println("You entered height"+height);
		System.out.println("You entered bmi"+bmi);
		
	}
	public static void main(String[] args)
	{
		patient pn=new patient();
		pn.BMI();
	}
}





