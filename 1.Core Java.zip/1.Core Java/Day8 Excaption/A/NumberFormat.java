import java.util.Scanner;
public class NumberFormat
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an integer: ");
		String str=sc.nextLine();
		
		try
		{
			int x = Integer.parseInt(str);
			System.out.println("The Square Value is: " + x * x);
			System.out.println("Success");
		}
		catch(NumberFormatException e)
		{
		     System.out.println("Entered input is not a valid format for an integer");
		}
		sc.close();
	}
}