import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexMobileEmailUrl2
{
    public static void main(String[] args)
	{
	    System.out.println(Pattern.matches("[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}","27/07/1999"));
		System.out.println(Pattern.matches("[0-3]?[0-9]-[0-3]?[0-9]-(?:[0-9]{2})?[0-9]{2}","27-07-1999"));
		System.out.println(Pattern.matches("[0-3]?[0-9].[0-3]?[0-9].(?:[0-9]{2})?[0-9]{2}","27.07.1999"));
	}
  
}