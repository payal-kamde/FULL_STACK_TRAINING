import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo1
{
	public static void main(String[] args)
	{
		try
		{
		FileOutputStream fout=new FileOutputStream("D:/JavaFullStackTrainning/Day10/abc.txt");
		BufferedOutputStream boutput=new BufferedOutputStream(fout);
		int i;
		String s="Payal";
		byte b[]=s.getBytes(); 
		boutput.write(b);
		boutput.close();
		fout.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
	