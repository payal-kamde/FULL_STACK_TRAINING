import java.io.FileInputStream;
class ExceptionDemo2
{
 public static void main(String args[])
 {
	 try
	 {
	 FileInputStream f = new FileInputStream("D:/xyz.text");
	 }
	 cathch(Exception e)
	 {
		 System.out.println(e);
	 }
	 
  
 }
}