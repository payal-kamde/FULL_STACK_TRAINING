package com.yash.springjdbcfirst.dao;

import com.yash.springjdbcfirst.entities.*;



import org.springframework.jdbc.core.JdbcTemplate;



public class EmployeeDaoImpl implements EmployeeDao
{



	private JdbcTemplate jdbctemp;


	public int insert(Employee emp)
	{
	
		String q = "insert into employee1(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmailid(), emp.getDob(), emp.getContactno(), emp.getSalary());
		return msg;
	}



	public JdbcTemplate getJdbctemp() 
	{
		return jdbctemp;
	}



	public void setJdbctemp(JdbcTemplate jdbctemp) 
	{
		this.jdbctemp = jdbctemp;
	}

	public int updatedetails(Employee emp)
	{
		// update details of student
		String q="update employee1 set emailid=?, dob=?, contactno=?, salary=? where empname=?";
		System.out.println(emp.toString());
		int msg=this.jdbctemp.update(q,  emp.getEmailid(), emp.getDob(), emp.getContactno(), emp.getSalary(), emp.getEmpname());
		return msg;
	}
	


	public int deletedetails(String empname)
	{
		// TODO Auto-generated method stub
		String q="delete from employee1 where empname=?";
		int msg=this.jdbctemp.update(q,empname);
		
		
		return msg;
		
		
	
	}



	public int deletedetails(Employee emp) {
		// TODO Auto-generated method stub
		return 0;
	}
}