class SumAveArray
{
 public static void main(String args[])
 {
  int[] a = {10,20,30,40,50};
  int sum=0;
  
  System.out.println("Print the all the element");
  
  
  for(int i=0;i<a.length;i++)
  {
   sum=sum+a[i];
   
  }
  System.out.println(sum);
  int avg=sum/5;
  System.out.println(avg);
 }
}



