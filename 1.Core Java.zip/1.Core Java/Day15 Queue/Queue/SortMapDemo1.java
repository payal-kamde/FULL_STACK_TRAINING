//sort map using key
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;
class SortMapDemo1
{
public static void main(String gg[])
{
Map<Integer,String> map=new HashMap<>();
map.put(100,"yash");
map.put(10,"tech");
map.put(20,"abc");
map.put(50,"xyz");
TreeMap<Integer,String> treeMap=new TreeMap<>(map);

for(Map.Entry m:treeMap.entrySet())
{
System.out.println("Key :"+m.getKey()+" Value :"+m.getValue());
}
}
}
