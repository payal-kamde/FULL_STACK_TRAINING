import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexMobileEmailUrl1
{
  public static void main(String args[])
  {
    Scanner sc = new Scanner(System.in);
	String number;
	String email;
	String url;
	
	System.out.println("Enter your Mobile number: ");
	number = sc.nextLine();
	
	System.out.println("Enter your Email Id: ");
	email = sc.nextLine();
	
	System.out.println("Enter your URL: ");
	url = sc.nextLine();
	
	
	Pattern p = Pattern.compile("^[0-9]{10}$");
	Matcher m = p.matcher(number);
	
	Pattern p1 = Pattern.compile("[a-zA-z0-9]{5,}[@]{1}[a-z]{5,}[.]{1}[a-z]{3}");
	Matcher m1 = p1.matcher(email);
	
	Pattern p2 = Pattern.compile("(https://)(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?");
	Matcher m2 = p2.matcher(email);
	
	if(m.find() && m1.find() && m2.find())
	{
	  System.out.println("Mobile number is valid");
	  System.out.println("Email Id is valid");
	  System.out.println("URL is valid");
	}
	else
	{
	  System.out.println("Mobile number is not valid");
	  System.out.println("Email Id is not valid");
	  System.out.println("URL is not valid");
	}
	
  }
  
 
  
}