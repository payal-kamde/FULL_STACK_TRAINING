
<!-- saved from url=(0051)file:///D:/JavaFullStackTrainning/Day28/Object.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"></head><body></body></html>