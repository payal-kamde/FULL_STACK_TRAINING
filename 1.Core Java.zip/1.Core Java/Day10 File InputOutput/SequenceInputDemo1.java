import java.io.*;    
class SequenceInputDemo1
{    
  public static void main(String args[])throws Exception  
  {  
   FileInputStream fin1=new FileInputStream("D:/JavaFullStackTrainning/Day10/abc.txt");    
   FileInputStream fin2=new FileInputStream("D:/JavaFullStackTrainning/Day10/xyz.txt");         
   SequenceInputStream s1=new SequenceInputStream(fin1,fin2);    
   int i;    
   while((i=s1.read())!=-1)    
   {    
     System.out.println((char)i);    
   }    
   s1.close();         
   fin1.close();      
   fin2.close();       

  }    
}    