class A
{
 int i = 10;
 
}
class B extends A
{
 int j= 20;
}
class C extends B
{
 int K =30;
}

class ClsCast
{
 public static void main(String[] args)
 {
   C c = new C();
   B b = (B)c;
   A a = (A)b;
  System.out.println(a.i);
 }
}