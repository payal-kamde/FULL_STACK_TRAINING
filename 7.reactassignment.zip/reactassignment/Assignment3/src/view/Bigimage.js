import React,{Component} from 'react';

class Bigimage extends React.Component

{

    render()

    {

        return(<div>

            <h1>Company</h1>
            <img src="img2.jpg" width="1246" height="400"></img>

        </div>);

    }

}

export default Bigimage;