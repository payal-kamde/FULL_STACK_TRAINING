class A
{
 void display()
 {
  System.out.println("I am in class A-Display");
 }
}
class SuperDemo2 extends A
{
 void display()
 {
  System.out.println("I am SuperDemo2-Display");
 }
 void show()
 {
  display();
  super.display();
  
 }
 public static void main(String args[])
 {
  SuperDemo2 sd = new SuperDemo2();
  sd.show();
 }
}