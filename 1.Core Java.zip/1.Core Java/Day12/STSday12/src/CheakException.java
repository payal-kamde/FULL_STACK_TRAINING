import java.lang.*;
import java.io.*;


public class CheakException {

	public static void main(String[] args)
	{
		 try
		   {
	        FileInputStream f = new FileInputStream("D:/ab.txt");
			
	       }
		   catch(FileNotFoundException e)
		   {
			   System.out.println(e);
		   }
		   //FileNotFoundException
			//java.io.FileNotFoundException: D:\ab.txt (The system cannot find the file specified)
			
			try 
			{
	            Class temp = Class.forName("Com.MYSQL"); 
	        }
	        catch (ClassNotFoundException e) 
			{
	            
	            System.out.println("Class does not exist check the name of the class");
	        }

	}

}
