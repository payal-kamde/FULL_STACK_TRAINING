import java.io.FileOutputStream;  
import java.io.BufferedOutputStream;  

class BufferedOutputDemo
{
	public static void main(String[] args)
	{
		try{
				 FileOutputStream fout=new FileOutputStream("D:\\testout.txt");    
				 BufferedOutputStream bout=new BufferedOutputStream(fout);    
				 String s="Welcome to Yash tech.";    
				 byte b[]=s.getBytes();    
				 bout.write(b);    
				 bout.flush();    
				 bout.close();    
				 fout.close();    			
		}
		catch(Exception e){
			
		}

	}
}