import java.io.*;  

class Main
{  
 void method()throws IOException
 {  
  throw new IOException("System Error");  
 }  
}  
public class ThrowsDemo2
{  
   public static void main(String args[])
   {  
    try
	{  
     Main m=new Main();  
     m.method();  
    }catch(Exception e)
	{
	System.out.println("exception handled carefully");
	}     
  
    System.out.println("Hello normal");  
  }  
}
