import java.io.BufferedReader;
import java.io.InputStreamReader;

class BufferedReader
{
 public static void main(String args[])throws Exception
 {
  InputStreamReader i = new InputStreamReader(System.in);
  BufferedReader br = new BufferedReader(i);
  String name = br.readLine();
  System.out.println(name);
 }
 
}