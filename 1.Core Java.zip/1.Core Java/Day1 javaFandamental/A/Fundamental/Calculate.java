class Calculate
{
 public static void main(String args[])
{
 double a = Double.parseDouble(args[0]);
 double b = Double.parseDouble(args[1]);
 double c;

 
operator= args[2].charAt(0);
 

 switch(operator){
 case'+':
 c=a+b;
 break;

 case'-':
 c=a-b;
 break;

 case'*':
 c=a*b;
 
 break;
 
 case'/':
 c=a/b;
 break;

 default:
 System.out.println("Invalid oparator");
 break;


}


}
}